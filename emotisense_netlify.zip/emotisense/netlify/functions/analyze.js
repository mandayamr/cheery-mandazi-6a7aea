exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const body = JSON.parse(event.body);
    const text = body.text;

    if (!text) {
      return { statusCode: 400, body: JSON.stringify({ error: 'No text provided' }) };
    }

    const prompt = `You are an emotion recognition AI. Analyze the emotional content of the following text and respond ONLY with a valid JSON object (no markdown, no explanation).

Text: "${text}"

Return exactly this structure:
{
  "primary_emotion": "joy|sadness|anger|fear|surprise|disgust|neutral|anticipation",
  "confidence": 0.0 to 1.0,
  "intensity": "low|medium|high",
  "emotion_scores": {
    "joy": 0.0,
    "sadness": 0.0,
    "anger": 0.0,
    "fear": 0.0,
    "surprise": 0.0,
    "disgust": 0.0,
    "neutral": 0.0,
    "anticipation": 0.0
  },
  "sentiment": "positive|negative|neutral|mixed",
  "empathetic_response": "A warm, brief 1-2 sentence empathetic response to the person based on their emotional state."
}`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': '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',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const err = await response.text();
      return { statusCode: response.status, body: JSON.stringify({ error: err }) };
    }

    const data = await response.json();
    const raw = data.content.map(b => b.text || '').join('');
    const result = JSON.parse(raw.replace(/```json|```/g, '').trim());

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result)
    };

  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
